package org.example.model;

public enum AccountStatus {
    CREATED,ACTIVATED,SUSPENDED,BLOCKED
}
