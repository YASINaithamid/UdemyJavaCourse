package org.example.model;

public class CurrentAccount extends BankAccount {
}
