package org.example.model;

public class SavingAccount  extends  BankAccount{
}
