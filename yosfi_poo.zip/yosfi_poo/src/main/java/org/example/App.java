package org.example;

import org.example.model.BankAccount;

public class App {
    public static void main(String[] args) {
        BankAccount [] accounts=new BankAccount[4];

    }
}
